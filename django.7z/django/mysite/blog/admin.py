from django.contrib import admin
from blog import models

# Register your models here.
class BlogPostAdmin(admin.ModelAdmin):
      list_display = ('title','timestamp') #将blog的title 和 timestamp 作为显示
admin.site.register(models.BlogPost,BlogPostAdmin) #注册BlogPost和BlogPostAdmin


