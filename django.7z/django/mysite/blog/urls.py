#blog.urls.py
#from django.conf.urls.defaults import *
from django.urls import path
import blog.views

urlpatterns = [
    path('', blog.views.archive), #默认进入blog目录，首页返回的是archive页面内容
    path('foo/',blog.views.foo),   #url:blog/foo 返回foo页面
    path('bar/',blog.views.bar),
]
