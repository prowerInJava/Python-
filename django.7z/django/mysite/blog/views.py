from django.shortcuts import render_to_response,render
from datetime import datetime
from django.template import loader
from django.http import HttpResponse
from blog.models import BlogPost
from django.http import HttpResponseRedirect
from blog.models import BlogPostForm
# Create your views here.

"""
def archive(request):
      post = BlogPost(title='mocktitle',body='mockbody hello',timestamp = datetime.now())
      return render_to_response('archive.html',{'posts':[post]})
"""

def archive(request):
      posts = BlogPost.objects.all()[:10] #.order_by('timestamp') #按时间升序排序
      #t = loader.get_template("archive.html")
      c = {'posts':posts,'form':BlogPostForm()}
      return  render(request,'archive.html',c)
#将archive函数简写
bar = lambda req:render_to_response('archive.html',
                                     {'posts':BlogPost.objects.all()[:10]})
#伪视图
def foo(request):
      post = BlogPost(title='foo',body='foo hello',timestamp = datetime.now())
      return render(request,'archive.html',{'posts':[post]})

def create_blogpost(request):
      """
      #注释掉违反DRY原则的代码（代码不要自我重复）
      if request.method =='POST':
            BlogPost(
                  title = request.POST.get('title'),
                  body = request.POST.get('body'),
                  timestamp = datetime.now(),
                  ).save()
      """
      if request.method == 'POST':
            form = BlogPostForm(request.POST)
            if form.is_valid():
                  post = form.save(commit=False)
                  post.timestamp=datetime.now()
                  post.save()
                  
      return HttpResponseRedirect('/blog/')
