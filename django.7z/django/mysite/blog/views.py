from django.shortcuts import render_to_response
from datetime import datetime
from django.template import loader
from django.http import HttpResponse
from blog.models import BlogPost
# Create your views here.

"""
def archive(request):
      post = BlogPost(title='mocktitle',body='mockbody hello',timestamp = datetime.now())
      return render_to_response('archive.html',{'posts':[post]})
"""

def archive(request):
      posts = BlogPost.objects.all() #.order_by('timestamp') #按时间升序排序
      t = loader.get_template("archive.html")
      c = {'posts':posts}
      return HttpResponse(t.render(c))
#将archive函数简写
bar = lambda req:render_to_response('archive.html',
                                     {'posts':BlogPost.objects.all()[:10]})
#伪视图
def foo(request):
      post = BlogPost(title='foo',body='foo hello',timestamp = datetime.now())
      return render_to_response('archive.html',{'posts':[post]})
